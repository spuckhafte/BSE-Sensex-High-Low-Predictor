def high_low_close(___open, ___true_high=None, ___true_low=None, ___true_close=None, ___graph=False, ___dpi=1000):
    from datetime import date as DT___
    import joblib as JB___
    import numpy as NP___
    import matplotlib.pyplot as PLT___
    __MODEL_high = JB___.load('sensexHighPredictionAlgorithm.joblib')
    __MODEL_low = JB___.load('sensexLowPredictionAlgorithm.joblib')
    __MODEL_close = JB___.load('sensexClosePredictionAlgorithm.joblib')

    __open = ___open
    __prediction_high = __MODEL_high.predict([[str(__open)]])
    __prediction_low = __MODEL_low.predict([[str(__open), str(__prediction_high[0])]])
    __prediction_close = __MODEL_close.predict([[str(__open), str(__prediction_high[0]), str(__prediction_low[0])]])

    if ___graph:
        if ___true_high is not None and ___true_low is not None and ___true_close is not None:
            __high = ___true_high
            __low = ___true_low
            __close = ___true_close

            __accuracy = (((abs(round(__prediction_high[0]) - __high) / __high) + (
                        abs(round(__prediction_low[0]) - __low) / __low) + (
                                       abs(round(__prediction_close[0]) - __close) / __close)) / 3) * 100

            __x_axis = [1, 1000, 2000, 3000]

            __y_axis_1 = [__open, __high, __low, __close]
            __y_axis_2 = [__open, round(__prediction_high[0]), round(__prediction_low[0]), round(__prediction_close[0])]

            PLT___.plot(__x_axis, __y_axis_1, label="Actual Value")
            PLT___.plot(__x_axis, __y_axis_2, label="Predicted")

            PLT___.xlabel('Event Order')
            PLT___.ylabel('Value')

            PLT___.title(f'Sensex Prediction - {DT___.today().strftime("%d/%m/%Y")}')
            PLT___.text(
                __x_axis[1], min(__y_axis_1 + __y_axis_2) - 500,
                "*value for open is not predicted",
                color='black', fontsize=10)

            PLT___.text(__x_axis[0], __y_axis_2[0] + 250, __y_axis_1[0], color="#1F77B4", fontsize=10)
            PLT___.text(__x_axis[0], __y_axis_2[0] + 100, __y_axis_2[0], color="#FF7F0E", fontsize=10)

            PLT___.text(__x_axis[1], __y_axis_2[1] + 250, __y_axis_1[1], color="#1F77B4", fontsize=10)
            PLT___.text(__x_axis[1], __y_axis_2[1] + 100, __y_axis_2[1], color="#FF7F0E", fontsize=10)

            PLT___.text(__x_axis[2], __y_axis_2[2] + 250, __y_axis_1[2], color="#1F77B4", fontsize=10)
            PLT___.text(__x_axis[2], __y_axis_2[2] + 100, __y_axis_2[2], color="#FF7F0E", fontsize=10)

            PLT___.text(__x_axis[3], __y_axis_2[3] + 250, __y_axis_1[3], color="#1F77B4", fontsize=10)
            PLT___.text(__x_axis[3], __y_axis_2[3] + 100, __y_axis_2[3], color="#FF7F0E", fontsize=10)

            PLT___.text(__x_axis[0], min(__y_axis_1 + __y_axis_2) - 800, 'Open', color="red", fontsize=10)
            PLT___.text(__x_axis[1], min(__y_axis_1 + __y_axis_2) - 800, 'High', color="red", fontsize=10)
            PLT___.text(__x_axis[2], min(__y_axis_1 + __y_axis_2) - 800, 'Low', color="red", fontsize=10)
            PLT___.text(__x_axis[3], min(__y_axis_1 + __y_axis_2) - 800, 'Close', color="red", fontsize=10)

            PLT___.text(0, 60987, f'Error: {str(round(__accuracy, 2))}%', color='red', fontsize=10)

            PLT___.legend()

            PLT___.xticks(NP___.arange(0, 4000, 500))
            PLT___.yticks(NP___.arange(min(__y_axis_1 + __y_axis_2) - 1000, max(__y_axis_1 + __y_axis_2) + 800, 140))
            PLT___.savefig(f'Sensex Graph {DT___.today().strftime("%d-%m-%Y")}.jpg', format="jpg", dpi=___dpi)
            PLT___.show()

            return __y_axis_2 + [__accuracy]

        else:
            __xa = [0, 1000, 2000, 3000]
            __ya = [__open, round(__prediction_high[0]), round(__prediction_low[0]), round(__prediction_close[0])]

            PLT___.plot(__xa, __ya)

            PLT___.xlabel('Event Order')
            PLT___.ylabel('Value')

            PLT___.title(f'Sensex Prediction - {DT___.today().strftime("%d/%m/%Y")}')
            PLT___.text(1500, 60300, "*value for open is not predicted", color='black', fontsize=10)

            PLT___.text(__xa[0] + 2, __ya[0] - 40, __ya[0], color="#1F77B4", fontsize=10)
            PLT___.text(__xa[1] + 40, __ya[1] - 10, __ya[1], color="#1F77B4", fontsize=10)
            PLT___.text(__xa[2] + 120, __ya[2] + 2, __ya[2], color="#1F77B4", fontsize=10)
            PLT___.text(__xa[3] - 200, __ya[3] + 20, __ya[3], color="#1F77B4", fontsize=10)

            PLT___.text(__xa[0] - 30, 60000, 'Open', color="red", fontsize=10)
            PLT___.text(__xa[1] - 30, 60000, 'High', color="red", fontsize=10)
            PLT___.text(__xa[2] - 30, 60000, 'Low', color="red", fontsize=10)
            PLT___.text(__xa[3] - 30, 60000, 'Close', color="red", fontsize=10)

            PLT___.savefig(f'Predicted Graph - {DT___.today().strftime("%d-%m-%Y")}.jpg', format="jpg", dpi=___dpi)

            PLT___.show()

            return __ya

    if ___graph is False:
        __output = [__open, round(__prediction_high[0]), round(__prediction_low[0]), round(__prediction_close[0])]
        if ___true_high is not None and ___true_low is not None and ___true_close is not None:
            __high = ___true_high
            __low = ___true_low
            __close = ___true_close
            __accuracy = (((abs(round(__prediction_high[0]) - __high) / __high) + (
                        abs(round(__prediction_low[0]) - __low) / __low) + (
                                       abs(round(__prediction_close[0]) - __close) / __close)) / 3) * 100
            return __output + [__accuracy]
        else:
            return __output


# predictions = high_low_close(60320, 60421, 59918, 60027, True)
# print(predictions)
